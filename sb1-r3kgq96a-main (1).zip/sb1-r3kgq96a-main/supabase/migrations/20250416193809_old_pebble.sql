/*
  # Initial Schema Setup for Travel Agent App

  1. New Tables
    - users
      - Custom fields for user profiles
      - Wallet balance tracking
    - bookings
      - Stores all booking information
      - Links to users and specific services
    - wallet_transactions
      - Tracks all wallet-related transactions
    - services
      - Stores ferry, hotel, sightseeing, and package details
  
  2. Security
    - Enable RLS on all tables
    - Add policies for role-based access
*/

-- Create custom types
CREATE TYPE user_role AS ENUM ('customer', 'agent', 'admin', 'driver');
CREATE TYPE booking_type AS ENUM ('ferry', 'hotel', 'sightseeing', 'package');
CREATE TYPE booking_status AS ENUM ('pending', 'confirmed', 'cancelled', 'completed');
CREATE TYPE transaction_type AS ENUM ('credit', 'debit');

-- Create users table
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY REFERENCES auth.users(id),
  email text UNIQUE NOT NULL,
  role user_role NOT NULL DEFAULT 'customer',
  agent_id text UNIQUE,
  company_name text,
  address text,
  zip_code text,
  city text,
  wallet_balance decimal(10,2) DEFAULT 0.00,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create bookings table
CREATE TABLE IF NOT EXISTS bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id),
  type booking_type NOT NULL,
  status booking_status DEFAULT 'pending',
  amount decimal(10,2) NOT NULL,
  booking_date timestamptz DEFAULT now(),
  travel_date timestamptz NOT NULL,
  details jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create wallet_transactions table
CREATE TABLE IF NOT EXISTS wallet_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id),
  amount decimal(10,2) NOT NULL,
  type transaction_type NOT NULL,
  description text,
  created_at timestamptz DEFAULT now()
);

-- Create services table
CREATE TABLE IF NOT EXISTS services (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type booking_type NOT NULL,
  name text NOT NULL,
  description text,
  price decimal(10,2) NOT NULL,
  details jsonb NOT NULL DEFAULT '{}',
  active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE wallet_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE services ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can read own data"
  ON users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id OR role = 'admin');

CREATE POLICY "Admins can update user data"
  ON users
  FOR UPDATE
  TO authenticated
  USING (role = 'admin');

CREATE POLICY "Users can update own profile"
  ON users
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Everyone can read active services"
  ON services
  FOR SELECT
  TO authenticated
  USING (active = true);

CREATE POLICY "Admins can manage services"
  ON services
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM users
    WHERE users.id = auth.uid()
    AND users.role = 'admin'
  ));

CREATE POLICY "Users can view own bookings"
  ON bookings
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
      AND (users.role = 'admin' OR users.role = 'agent')
    )
  );

CREATE POLICY "Users can create bookings"
  ON bookings
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can view own transactions"
  ON wallet_transactions
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
      AND users.role = 'admin'
    )
  );

-- Functions
CREATE OR REPLACE FUNCTION generate_agent_id()
RETURNS trigger AS $$
DECLARE
  next_id text;
BEGIN
  SELECT 'ETAAB' || LPAD(COALESCE(
    (SELECT SUBSTRING(agent_id FROM 6)::integer + 1
     FROM users
     WHERE agent_id LIKE 'ETAAB%'
     ORDER BY agent_id DESC
     LIMIT 1
    ), 1)::text, 4, '0')
  INTO next_id;
  
  NEW.agent_id := next_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER set_agent_id
  BEFORE INSERT ON users
  FOR EACH ROW
  WHEN (NEW.role = 'agent')
  EXECUTE FUNCTION generate_agent_id();

-- Function to handle wallet transactions
CREATE OR REPLACE FUNCTION process_wallet_transaction(
  p_user_id uuid,
  p_amount decimal,
  p_type transaction_type,
  p_description text
)
RETURNS void AS $$
BEGIN
  -- Insert transaction record
  INSERT INTO wallet_transactions (user_id, amount, type, description)
  VALUES (p_user_id, p_amount, p_type, p_description);

  -- Update user's wallet balance
  UPDATE users
  SET wallet_balance = CASE
    WHEN p_type = 'credit' THEN wallet_balance + p_amount
    WHEN p_type = 'debit' THEN wallet_balance - p_amount
  END
  WHERE id = p_user_id;
END;
$$ LANGUAGE plpgsql;