export type UserRole = 'customer' | 'agent' | 'admin' | 'driver';

export interface User {
  id: string;
  email: string;
  role: UserRole;
  agent_id?: string;
  company_name?: string;
  address?: string;
  zip_code?: string;
  city?: string;
  wallet_balance: number;
}

export interface Booking {
  id: string;
  user_id: string;
  type: 'ferry' | 'hotel' | 'sightseeing' | 'package';
  status: 'pending' | 'confirmed' | 'cancelled' | 'completed';
  amount: number;
  booking_date: string;
  travel_date: string;
  details: any;
}

export interface WalletTransaction {
  id: string;
  user_id: string;
  amount: number;
  type: 'credit' | 'debit';
  description: string;
  created_at: string;
}