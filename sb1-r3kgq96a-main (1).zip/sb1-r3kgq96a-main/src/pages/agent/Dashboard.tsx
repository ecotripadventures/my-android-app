import React, { useState } from 'react';
import { useAuthStore } from '../../store/authStore';
import { Ship, Hotel, Map, Package, FileText, Settings } from 'lucide-react';

type Tab = 'ferry' | 'hotels' | 'sightseeing' | 'packages' | 'bookings' | 'settings';

export default function AgentDashboard() {
  const { user } = useAuthStore();
  const [activeTab, setActiveTab] = useState<Tab>('ferry');

  const tabs = [
    { id: 'ferry', name: 'Ferry', icon: Ship },
    { id: 'hotels', name: 'Hotels', icon: Hotel },
    { id: 'sightseeing', name: 'Sightseeing', icon: Map },
    { id: 'packages', name: 'Packages', icon: Package },
    { id: 'bookings', name: 'Booking Report', icon: FileText },
    { id: 'settings', name: 'Settings', icon: Settings },
  ] as const;

  return (
    <div className="min-h-screen bg-gray-100">
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex">
              <div className="flex-shrink-0 flex items-center">
                <span className="text-xl font-bold text-gray-800">
                  Agent Portal
                </span>
              </div>
              <div className="hidden sm:ml-6 sm:flex sm:space-x-8">
                {tabs.map(({ id, name, icon: Icon }) => (
                  <button
                    key={id}
                    onClick={() => setActiveTab(id)}
                    className={`${
                      activeTab === id
                        ? 'border-blue-500 text-gray-900'
                        : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
                    } inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium`}
                  >
                    <Icon className="h-5 w-5 mr-2" />
                    {name}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <span className="text-sm text-gray-500">Agent ID:</span>
                <span className="ml-2 text-sm font-medium text-gray-900">
                  {user?.agent_id}
                </span>
              </div>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          <div className="bg-white rounded-lg shadow p-6">
            {activeTab === 'ferry' && <div>Ferry Booking Management</div>}
            {activeTab === 'hotels' && <div>Hotel Booking Management</div>}
            {activeTab === 'sightseeing' && <div>Sightseeing Tour Management</div>}
            {activeTab === 'packages' && <div>Travel Package Management</div>}
            {activeTab === 'bookings' && <div>Booking Reports</div>}
            {activeTab === 'settings' && (
              <div>
                <h2 className="text-lg font-medium text-gray-900 mb-4">Account Settings</h2>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Company Name</label>
                    <input
                      type="text"
                      className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                      value={user?.company_name || ''}
                      readOnly
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Wallet Balance</label>
                    <div className="mt-1 block w-full text-lg font-semibold text-gray-900">
                      ₹{user?.wallet_balance.toFixed(2)}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}