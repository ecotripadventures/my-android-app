import React from 'react';
import { useAuthStore } from '../../store/authStore';

export default function CustomerDashboard() {
  const { user } = useAuthStore();

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Customer Dashboard</h1>
        <div className="bg-white rounded-lg shadow p-6">
          <p className="text-gray-600">Welcome back, {user?.email}</p>
        </div>
      </div>
    </div>
  );
}